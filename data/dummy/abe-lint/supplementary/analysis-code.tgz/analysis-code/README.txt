Analysis code for the tremendous hunch (fictional fixture).
This archive exists only to make the supplementary archive check fire.
